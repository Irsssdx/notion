	const lightmode = () => {
			var x = document.getElementsByTagName("body")[0];
			var btn = document.getElementById("light-mode");
			
			if(btn.innerHTML == "LIGHT MODE") {
				btn.innerHTML = "DARK MODE";
				x.style.backgroundColor = "white";
				x.style.color = "#222";	
			} else {
				btn.innerHTML = "LIGHT MODE";
				x.style.backgroundColor = "#35363a";
				x.style.color = "#e8ead0";
			}
		}